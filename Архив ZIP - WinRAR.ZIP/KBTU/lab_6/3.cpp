#include <bits/stdc++.h>
using namespace std;


int partition(int ar[], int low, int high) {
	int pivot = ar[high];
	int i = low-1;
	for (int j = low; j <= high-1; j++) {
		if(ar[j] < pivot) {
			i++;
			swap(ar[i], ar[j]);
		}
	}
	swap(ar[i+1], ar[high]);
	return i+1;
}

void quick_sort(int ar[], int low, int high) {
	if (low < high) {
		int p = partition(ar, low, high);
		quick_sort(ar, low, p - 1);
		quick_sort(ar, p + 1, high);
	}
}
int main(){
    int n;
    cin>>n;
    int min = INT_MAX;
    vector<int> v;
    int a[n];
    for(int i = 0 ; i < n ; i++){
        cin>>a[i];
    }
    quick_sort(a, 0 , n-1);
    for(int i = 0 ; i < n ; i++){
        if(abs(a[i+1] - a[i]) < min){
            min = abs(a[i+1] - a[i]);
            v.clear();
            v.push_back(a[i]);
            v.push_back(a[i+1]);
        }
        else if(abs(a[i+1] - a[i]) == min){
            v.push_back(a[i]);
            v.push_back(a[i+1]);
        }
    }
    for(auto i : v){
        cout << i << " ";
    }

}