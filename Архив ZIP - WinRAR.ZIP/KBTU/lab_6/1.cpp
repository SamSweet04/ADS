#include <iostream>
using namespace std;

bool isVowel(char c) {
	return c == 'a' || c == 'e' || c == 'o' || c == 'i' || c == 'u';
}

int partition(string & ar, int low, int high) {
	char pivot = ar[high];
	int i = low-1;
	for (int j = low; j <= high-1; j++) {
		if (isVowel(ar[j]) && !isVowel(pivot)) {
			i++;
			swap(ar[j], ar[i]);
		} else if (!isVowel(ar[j]) && isVowel(pivot)) {
			continue;
		} else if (ar[j] < pivot) {
			i++;
			swap(ar[j], ar[i]);
			cout << ar[j] << " " << ar[i] << " " << ar <<endl;
		}
	}
	swap(ar[i+1], ar[high]);
	return i+1;
}

void quick_sort(string& ar, int low, int high) {
	if (low < high) {
		int p = partition(ar, low, high);
		quick_sort(ar, low, p - 1);
		quick_sort(ar, p + 1, high);
	}
}

int main() {

	int n;
	cin >> n;
	string s;
	cin >> s;
	quick_sort(s, 0, n - 1);
	cout << s;
	return 0;
}